<#
.SYNOPSIS
    Commander Winget Downloader
    1. Supports manual hash input via command line (-ManualHash).
    2. Auto-strips 'sha256:' prefix from input.
    3. Robust HTML parsing (Multi-line support).
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, Position = 0)]
    [string] $Url,

    # [옵션] 해시값을 알고 있다면 직접 입력 (파싱 건너뜀)
    [Parameter(Mandatory = $false)]
    [string] $ManualHash,

    [string] $OutDir = "$env:USERPROFILE\Downloads",
    [string] $InstallerType = 'exe',
    [string] $Architecture = 'x64'
)

$ErrorActionPreference = "Stop"

# -------------------------------------------------
# Helper Function: Clean Hash String
# -------------------------------------------------
function Clean-Hash {
    param([string]$InputStr)
    if ([string]::IsNullOrWhiteSpace($InputStr)) { return $null }
    
    # Remove 'sha256:' prefix and whitespace
    $Cleaned = $InputStr -replace "sha256:", ""
    $Cleaned = $Cleaned.Trim()
    return $Cleaned
}

# -------------------------------------------------
# 1. Setup & URL Parsing
# -------------------------------------------------
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host " Commander Downloader" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan

try {
    $Uri = [System.Uri]$Url
    $FileName = $Uri.Segments[-1].Trim("/")
    
    # Convert Download URL to Release Page URL
    $BaseUrl = $Url -replace "/download/", "/tag/"
    $ReleasePageUrl = $BaseUrl.Substring(0, $BaseUrl.LastIndexOf('/'))
    
    Write-Host "Target URL: $Url" -ForegroundColor Gray
	Write-Host "Target File: $FileName" -ForegroundColor Gray
	Write-Host "Target Release: $ReleasePageUrl" -ForegroundColor Gray
}
catch {
    Write-Error "URL Parsing Error."
    exit 1
}

# -------------------------------------------------
# 2. Hash Strategy (Manual vs Auto)
# -------------------------------------------------
$FinalHash = $null

# Case A: User provided hash via command line
if (-not [string]::IsNullOrWhiteSpace($ManualHash)) {
    Write-Host "`n[Mode] Manual Hash Provided" -ForegroundColor Cyan
    $FinalHash = Clean-Hash -InputStr $ManualHash
    Write-Host " -> Using provided hash: $FinalHash" -ForegroundColor Yellow
}
# Case B: Auto-Parsing from HTML
else {
    Write-Host "`n[Mode] Auto-Parsing HTML" -ForegroundColor Cyan
    Write-Host " -> Fetching Release Page..." -NoNewline -ForegroundColor Gray
    
    $TempHtml = Join-Path $env:TEMP ("gh_page_" + [guid]::NewGuid().ToString() + ".html")
    $curlArgs = @("-L", "-k", "--fail", "-s", "-o", "$TempHtml", "$ReleasePageUrl")
    
    try {
        $proc = Start-Process -FilePath "curl.exe" -ArgumentList $curlArgs -Wait -NoNewWindow -PassThru
        
        # Retry logic for 'v' prefix
        if ($proc.ExitCode -ne 0) {
            $ReleasePageUrl_V = $ReleasePageUrl -replace "tag/([\d\.]+)", "tag/v`$1"
            $curlArgs = @("-L", "-k", "--fail", "-s", "-o", "$TempHtml", "$ReleasePageUrl_V")
            $proc = Start-Process -FilePath "curl.exe" -ArgumentList $curlArgs -Wait -NoNewWindow -PassThru
        }
        
        if ($proc.ExitCode -eq 0 -and (Get-Item $TempHtml).Length -gt 0) {
            Write-Host " Done." -ForegroundColor Green
            $HtmlContent = Get-Content -Path $TempHtml -Raw
            
            # [Robust Regex for your HTML]
            # (?s) : Single-line mode (dot matches newline)
            # <clipboard-copy : Start tag
            # [^>]*? : Match content inside tag lazily
            # aria-label="[^"]*FILENAME : Find filename inside aria-label
            # value="sha256:([a-fA-F0-9]{64})" : Capture the hash in value attribute
            
            $EscapedName = [regex]::Escape($FileName)
            $Pattern = '(?s)<clipboard-copy[^>]*?aria-label="[^"]*' + $EscapedName + '[^"]*"[^>]*?value="sha256:([a-fA-F0-9]{64})"'
            
            if ($HtmlContent -match $Pattern) {
                $FinalHash = $matches[1]
                Write-Host " -> Hash Found: $FinalHash" -ForegroundColor Green
            } else {
                Write-Warning "`nParsed HTML but regex failed to match '$FileName'."
            }
        }
    }
    catch {
        Write-Warning "Could not download HTML source."
    }
    finally {
        if (Test-Path $TempHtml) { Remove-Item $TempHtml -Force }
    }
}

# -------------------------------------------------
# 3. Fallback: Interactive Input
# -------------------------------------------------
if (-not $FinalHash) {
    Write-Host "`n"
    Write-Host "#############################################" -ForegroundColor Red
    Write-Host " HASH REQUIRED" -ForegroundColor Red
    Write-Host "#############################################" -ForegroundColor Red
    Write-Host "Could not find hash automatically." -ForegroundColor Yellow
    Write-Host "Please copy the hash (or 'sha256:...') from GitHub Release page." -ForegroundColor Gray
    Write-Host "Page: $ReleasePageUrl" -ForegroundColor Gray
    
    while (-not $FinalHash) {
        $InputStr = Read-Host "`n>>> Paste Hash here"
        $Cleaned = Clean-Hash -InputStr $InputStr
        
        if ($Cleaned.Length -eq 64) {
            $FinalHash = $Cleaned
        } else {
            Write-Warning "Invalid length ($($Cleaned.Length)). SHA-256 must be 64 chars."
        }
    }
}

# -------------------------------------------------
# 4. Winget Execution
# -------------------------------------------------
Write-Host "`n[Phase 2] Winget Download..." -ForegroundColor Cyan

$manifestContent = @"
PackageIdentifier: DynamicApp.Commander
PackageVersion: 1.0.0
PackageLocale: en-US
Publisher: DynamicPublisher
PackageName: DynamicPackage
License: MIT
ShortDescription: Commander download
ManifestType: singleton
ManifestVersion: 1.1.0
Installers:
  - Architecture: $Architecture
    InstallerType: $InstallerType
    InstallerUrl: "$Url"
    InstallerSha256: $FinalHash
"@

$tempMan = Join-Path $env:TEMP ("dynamic_" + [guid]::NewGuid().ToString() + ".yaml")
[System.IO.File]::WriteAllText($tempMan, $manifestContent, [System.Text.Encoding]::UTF8)

$TempDL = Join-Path $env:TEMP ("winget_dl_" + [guid]::NewGuid().ToString())
New-Item -ItemType Directory -Path $TempDL -Force | Out-Null

$wingetArgs = @(
    'download', '--manifest', $tempMan, '-d', $TempDL,
    '--accept-package-agreements', '--accept-source-agreements', '--disable-interactivity'
)

$proc = Start-Process -FilePath "winget" -ArgumentList $wingetArgs -Wait -NoNewWindow -PassThru

# -------------------------------------------------
# 5. Finalize
# -------------------------------------------------
if ($proc.ExitCode -eq 0) {
    $file = Get-ChildItem -Path $TempDL -File | Select-Object -First 1
    if ($file) {
        if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Path $OutDir -Force | Out-Null }
        $FinalPath = Join-Path $OutDir $FileName
        if (Test-Path $FinalPath) { Remove-Item $FinalPath -Force }
        Move-Item -Path $file.FullName -Destination $FinalPath -Force
        
        Write-Host "`n[SUCCESS] Download Completed!" -ForegroundColor Green
        Write-Host "File: $FinalPath" -ForegroundColor Yellow
    }
} else {
    Write-Error "`n[ERROR] Winget Failed (ExitCode: $($proc.ExitCode))"
}

# Cleanup
Remove-Item $tempMan -Force -ErrorAction SilentlyContinue
Remove-Item $TempDL -Recurse -Force -ErrorAction SilentlyContinue