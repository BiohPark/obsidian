<#
.SYNOPSIS
    Bypasses local hash calculation (Proxy/Firewall friendly).
    Injects a dummy hash and forces Winget to ignore the mismatch.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, Position = 0)]
    [string] $Url,

    [Parameter(Mandatory = $true, Position = 1)]
    [ValidateSet('exe','msi','msix','zip','appx')]
    [string] $InstallerType,

    [Parameter(Mandatory = $true, Position = 2)]
    [ValidateSet('x86','x64','arm','arm64')]
    [string] $Architecture,

    [string] $OutDir = "$env:USERPROFILE\Downloads",
    [string] $Identifier = 'DynamicApp.Custom',
    [string] $Version = '1.0.0'
)

$ErrorActionPreference = "Stop"

# -------------------------------------------------
# 1. 가짜 해시 생성 (Dummy Hash)
# - Winget이 "해시값이 없다"며 뻗는 것을 방지하기 위해 형식을 맞춘 가짜 값을 넣습니다.
# - 사전 다운로드 과정을 완전히 생략합니다. (프록시 문제 해결)
# -------------------------------------------------
Write-Host "1. Generating manifest with Dummy Hash..." -ForegroundColor Cyan

# SHA-256 형식(64글자)의 아무 의미 없는 가짜 해시
$dummyHash = "A" * 64 

# -------------------------------------------------
# 2. YAML 매니페스트 생성
# -------------------------------------------------
$manifestContent = @"
PackageIdentifier: $Identifier
PackageVersion: $Version
PackageLocale: en-US
Publisher: DynamicPublisher
PackageName: DynamicPackage
License: MIT
ShortDescription: Dynamic download via script
ManifestType: singleton
ManifestVersion: 1.1.0
Installers:
  - Architecture: $Architecture
    InstallerType: $InstallerType
    InstallerUrl: "$Url"
    InstallerSha256: $dummyHash
"@

# -------------------------------------------------
# 3. 파일 저장 (BOM 없는 UTF-8)
# -------------------------------------------------
$tempMan = Join-Path $env:TEMP ("dynamic_{0}.yaml" -f [guid]::NewGuid())
[System.IO.File]::WriteAllText($tempMan, $manifestContent, [System.Text.Encoding]::UTF8)

# -------------------------------------------------
# 4. Winget 실행 (보안 해시 무시 옵션 필수)
# -------------------------------------------------
Write-Host "2. Offloading download to Winget..." -ForegroundColor Cyan
Write-Host " (Using --ignore-security-hash to bypass mismatch)" -ForegroundColor Gray

$wingetArgs = @(
    'download',
    '--manifest', $tempMan,
    '-d', $OutDir,
    '--accept-package-agreements',
    '--accept-source-agreements',
    '--disable-interactivity',
    '--ignore-security-hash', # <--- 핵심: 가짜 해시이므로 검증 실패를 무시하라고 명령
    '--verbose-logs' # 로그를 자세히 봐서 프록시 통과 여부 확인
)

$proc = Start-Process -FilePath "winget" -ArgumentList $wingetArgs -Wait -NoNewWindow -PassThru

if ($proc.ExitCode -eq 0) {
    Write-Host "`n✅ Download Succeeded!" -ForegroundColor Green
    Write-Host "📂 File saved to: $OutDir" -ForegroundColor Yellow
    Remove-Item $tempMan -Force -ErrorAction SilentlyContinue
}
else {
    Write-Error "`n❌ Winget Failed (ExitCode: $($proc.ExitCode))"
    Write-Warning "Manifest preserved at: $tempMan"
    Write-Host "Tip: If this fails, your proxy might be blocking Winget itself." -ForegroundColor Red
}
